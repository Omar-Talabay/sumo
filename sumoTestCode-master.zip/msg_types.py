# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 17:28:48 2018

@author: otalabay
"""

LOCAL_INFO = 1
LSM = 2
TLS = 3
TLS_STOP = 4
DANGER = 5
STOP_DANGER = 6
PM = 7
PM_STOP = 8